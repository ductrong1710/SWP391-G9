using Microsoft.EntityFrameworkCore;
using Businessobjects.Models;

namespace Businessobjects.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Profile> Profiles { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Example seed data with fixed GUIDs
            modelBuilder.Entity<User>().HasData(
                new User
                {
                    UserId = new Guid("c9d4c053-49b6-410c-bc78-2d54a9991870"),
                    Username = "admin",
                    Password = "admin123",
                    Role = "Admin"
                },
                new User
                {
                    UserId = new Guid("d8663e5e-7494-4f81-8739-6e0de1bea7ee"),
                    Username = "user",
                    Password = "user123",
                    Role = "User"
                }
            );

            // Example profile seed data
            modelBuilder.Entity<Profile>().HasData(
                new Profile
                {
                    ProfileId = new Guid("f5b7824f-5e35-4682-98d1-0e98f8dd6b31"),
                    Name = "Admin User",
                    DateOfBirth = new DateTime(1990, 1, 1),
                    Sex = "Male",
                    Class = "Admin",
                    Phone = "1234567890",
                    UserId = new Guid("c9d4c053-49b6-410c-bc78-2d54a9991870"),
                    Note = "Administrator profile",
                    User = new User // Required member 'User' initialized
                    {
                        UserId = new Guid("c9d4c053-49b6-410c-bc78-2d54a9991870"),
                        Username = "admin",
                        Password = "admin123",
                        Role = "Admin"
                    }
                }
            );
        }
    }
}