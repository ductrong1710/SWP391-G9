using Businessobjects.Models;
using Repositories;

namespace Services
{
    public class MedicationService : IMedicationService
    {
        private readonly IMedicationRepository _medicationRepository;

        public MedicationService(IMedicationRepository medicationRepository)
        {
            _medicationRepository = medicationRepository;
        }

        public async Task<IEnumerable<Medication>> GetAllMedicationsAsync()
        {
            return await _medicationRepository.GetAllMedicationsAsync();
        }

        public async Task<Medication?> GetMedicationByIdAsync(int id)
        {
            return await _medicationRepository.GetMedicationByIdAsync(id);
        }

        public async Task<IEnumerable<Medication>> GetExpiredMedicationsAsync()
        {
            return await _medicationRepository.GetExpiredMedicationsAsync();
        }

        public async Task<IEnumerable<Medication>> GetLowStockMedicationsAsync(int threshold = 10)
        {
            return await _medicationRepository.GetLowStockMedicationsAsync(threshold);
        }

        public async Task<Medication> CreateMedicationAsync(Medication medication)
        {
            await _medicationRepository.CreateMedicationAsync(medication);
            return medication;
        }

        public async Task UpdateMedicationAsync(int id, Medication medication)
        {
            if (id != medication.MedicationId)
                throw new ArgumentException("ID mismatch");

            if (!await _medicationRepository.MedicationExistsAsync(id))
                throw new KeyNotFoundException("Medication not found");

            await _medicationRepository.UpdateMedicationAsync(medication);
        }

        public async Task DeleteMedicationAsync(int id)
        {
            if (!await _medicationRepository.MedicationExistsAsync(id))
                throw new KeyNotFoundException("Medication not found");

            await _medicationRepository.DeleteMedicationAsync(id);
        }
    }
}